const Discord = require("discord.js");

const WS = require('./Webinterface/Webinterface')

const client = new Discord.Client();

var ws = new WS('1234', 4567, client)

client.on('ready', () => {
    console.log(`ModdingZone listener Success Started! ${client.user.tag}`)
})


client.login('Your token here')